#include<iostream>
#include<cvraman/body.h>

unsigned int Body::global_id = 0;

void Body::add_force(Force* force){
    this->physics.forces.push_back(force);
}

void Body::set_mass(float mass){
    this->physics.mass = mass;
}

void Body::set_position(const vec2 pos){
    this->physics.position = pos;
}

void Body::set_shape(Primitive* shape){
    this->shape = shape;
}

mat4* Body::get_transform(){
    return this->physics.get_transform();
}

vec2 Body::get_position(){
    return this->physics.position;
}

void Body::update_physics(float dt){
    this->physics.clear();
    this->physics.update(dt);
}

Body::Body(float mass, vec2 pos){
    this->set_position(pos);
    this->set_mass(mass);
}

Body::Body(vec2 pos, vec2 vel, vec2 acc){
    this->set_position(pos);
    this->physics.velocity = vel;
    this->physics.acceleration = acc;
}

void Body::debug(){
    std::cout<<"====== BODY ID ("<<this->id<<") ======"<<std::endl;
    this->physics.debug();
    std::cout<<"========================"<<std::endl;
}
