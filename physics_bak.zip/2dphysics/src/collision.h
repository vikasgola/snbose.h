#pragma once
#include<map>
#include<string>

#include "primitive.h"
#include "physics.h"
#include "body.h"

class CollisionDetector{
    std::string s1;
    std::string s2;
    public:
        CollisionDetector(std::string s1, std::string s2): s1(s1), s2(s2){};
        virtual bool are_colliding(Body* b1, Body* b2) = 0;
};

// class CircleCircleDetector: public CollisionDetector{
//     public:
//         bool are_colliding(Primitive* s1, Physics* p1, Primitive* s2, Physics* p2){

//         }
// };

class Collider{
    std::map<std::pair<std::string, std::string>, CollisionDetector*> detectors;
    public:
        void add_detector(CollisionDetector *detector);
        bool check_collision(Body* b1, Body* b2);
};