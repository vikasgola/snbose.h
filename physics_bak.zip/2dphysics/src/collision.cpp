#include "collision.h"
#include<iostream>

void Collider::add_detector(CollisionDetector* detector){

}

bool Collider::check_collision(Body* b1, Body* b2){
    std::pair<std::string, std::string> combo = {b1->get_shape()->get_type(), b2->get_shape()->get_type()};
    if(this->detectors.find(combo) == this->detectors.end()){
        // std::cout<<"DEBUG: No Collision Detection exists for "<<combo.first<<"x"<<combo.second<<std::endl;
        return false;
    }
    return this->detectors[combo]->are_colliding(b1, b2);
}
