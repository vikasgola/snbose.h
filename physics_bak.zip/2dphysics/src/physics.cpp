#include<iostream>
#include<cvraman/physics.h>

void Physics::update(float dt){
    if(this->mass == 0.0) return;
    this->update_forces();

    this->acceleration = this->total_force/this->mass;
    this->velocity = this->velocity + this->acceleration*dt;
    this->position = this->position + this->velocity*dt;

    this->angular_acceleration = this->total_torque;
    this->angular_velocity += this->angular_acceleration*dt;
    this->angle += this->angular_velocity*dt;

    this->model = transform(
        vec3(1.0),
        vec3(0.0, 0.0, this->angle),
        vec3(this->position.x, this->position.y, 0.0)
    );
}

void Physics::update_forces(){
    for(auto &force: this->forces){
        force->update(this);
        this->total_force = this->total_force + force->value;
    }
}

void Physics::debug(){
    std::cout<<"pos: "<<position<<std::endl;
    std::cout<<"vel: "<<velocity<<std::endl;
    std::cout<<"acc: "<<acceleration<<std::endl;
}

void Physics::clear(){
    this->total_force = vec2(0.0);
    this->total_torque = 0.0;
}

mat4* Physics::get_transform(){
    this->model = transform(
        vec3(1.0),
        vec3(0.0, 0.0, this->angle),
        vec3(this->position.x, this->position.y, 0.0)
    );
    return &this->model;
}
