#include<cvraman/primitive.h>

bool Line2D::contains(const Point2D& p) {
    vec2 dyx = this->end - this->start;
    float m = dyx.y / dyx.x;
    float b = this->start.y - m * this->start.x;
    return CMP(p.y, m * p.x + b);
}

Circle::Circle(const float radius, const unsigned int edges_count): radius(radius), edges_count(edges_count){
    this->vertices = new float[(this->edges_count+2)*3];

    int j = 0;
    this->vertices[j++] = this->center.x;
    this->vertices[j++] = this->center.y;
    this->vertices[j++] = 0.0;

    float angle = 0;
    for(size_t i=0;i<this->edges_count+1;i++){
        this->vertices[j++] = radius*sinf(angle);
        this->vertices[j++] = radius*cosf(angle);
        this->vertices[j++] = 0.0;
        angle += 2*M_PI/this->edges_count;
    }
}

Circle::~Circle(){
    delete[] this->vertices;
}

unsigned int Circle::get_vertex_count(){
    return this->edges_count+2;
}

