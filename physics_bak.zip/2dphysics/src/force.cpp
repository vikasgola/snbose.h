#include<cvraman/force.h>


Gravity::Gravity(vec2 gravity){
    this->g = gravity;
}

void Gravity::update(const Physics* physics){
    this->value = this->g*physics->mass;
}
