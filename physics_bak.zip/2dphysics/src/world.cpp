#include<cvraman/world.h>

World::World(vec2 gravity){
    this->gravity = Gravity(gravity);
}

void World::add_body(Body *body){
    body->add_force(&this->gravity);
    this->bodies.push_back(body);
}

unsigned int World::get_bodies_count(){
    return this->bodies.size();
}

void World::step(float dt){
    // UPDATE all the bodies
    for(auto &body: this->bodies){
        body->update_physics(dt);
    }

    // check for collisions
    for(size_t i=0;i<this->get_bodies_count();i++){
        for(size_t j=i+1;j<this->get_bodies_count();j++){
            Body* a = this->bodies[i];
            Body* b = this->bodies[j];
            this->collider.check_collision(a, b);
        }
    }

    // update bodies according to collision

}

void World::debug(){
    for(auto &body: this->bodies){
        body->debug();
    }
}