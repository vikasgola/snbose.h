#pragma once
#include<vector>

#include<advmath/advmath.h>
#include<cvraman/force.h>

class Force;

class Physics{
    mat4 model;
    public:
        float mass = 0.0;
        vec2 position;
        vec2 velocity;
        vec2 acceleration;
        vec2 total_force;
        std::vector<Force*> forces;

        float angle = 0.0;
        float angular_velocity;
        float angular_acceleration;
        float total_torque;

        void update_forces();
        void update(float dt);
        void clear();
        mat4* get_transform();

        void debug();
};
