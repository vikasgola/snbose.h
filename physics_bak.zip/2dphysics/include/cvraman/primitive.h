#pragma once
#include<advmath/advmath.h>
#include<cfloat>
#include<cmath>

#define CMP(x, y)                    \
    (\
        fabsf( (x)-(y) ) <= FLT_EPSILON * \
        fmaxf(1.0f,                    \
        fmaxf(fabsf(x), fabsf(y)))     \
   )

typedef vec2 Point2D;

class Line2D{
    public:
        Point2D start;
        Point2D end;
        inline Line2D(){}
        Line2D(const Point2D& s, const Point2D& e):start(s), end(e){
        }

        inline float length(){
            return (this->end-this->start).mag();
        }

        bool contains(const Point2D& p);
};

class Primitive{
    public:
        float *vertices;
        unsigned int *indices;
        unsigned int vertex_layout[1] = {3};
        virtual unsigned int get_vertex_count() = 0;
        virtual std::string get_type() = 0;

        float* get_vertex(){
            return this->vertices;
        };
        unsigned int* get_vertex_layout(){
            return this->vertex_layout;
        };
};

class Circle: public Primitive{
    Point2D center;
    float radius;
    const unsigned int edges_count;
    public:
        Circle(const float radius = 1.0, const unsigned int edges_count = 40);
        ~Circle();
        unsigned int get_vertex_count();
        std::string get_type(){ return "CIRCLE";}
};
