#pragma once
#include<vector>

#include<advmath/advmath.h>
#include<cvraman/force.h>
#include<cvraman/body.h>
#include<cvraman/collision.h>

class World{
    public:
        Gravity gravity;
        std::vector<Body*> bodies;
        Collider collider;

        World(){}
        World(vec2 gravity);

        void add_body(Body *body);
        unsigned int get_bodies_count();
        void step(float dt);
        void debug();
};
