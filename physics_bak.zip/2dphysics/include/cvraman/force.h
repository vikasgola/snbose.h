#pragma once
#include<advmath/advmath.h>
#include<cvraman/physics.h>

class Physics;

class Force{
    public:
        vec2 value;
        virtual void update(const Physics* physics) = 0;
};

class Gravity: public Force{
    vec2 g;
    public:
        Gravity(){};
        Gravity(vec2 g);
        void update(const Physics* physics);
};
