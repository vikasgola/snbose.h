#pragma once

#include<advmath/advmath.h>
#include<cvraman/physics.h>
#include<cvraman/force.h>
#include<cvraman/primitive.h>

class Body{
    private:
        static unsigned int global_id;
        unsigned int id = Body::global_id++;
        Physics physics;

    public:
        Primitive *shape;
        Body(){}
        Body(float mass, vec2 pos);
        Body(vec2 pos = vec2(0.0), vec2 vel = vec2(0.0), vec2 acc = vec2(0.0));

        void add_force(Force* force);
        void update_physics(float dt);
        void set_mass(float mass);
        void set_position(const vec2 pos);
        void set_shape(Primitive *shape);

        Primitive* get_shape(){return this->shape;}
        vec2 get_position();
        mat4* get_transform();
        inline unsigned int get_id(){return this->id;}

        void debug();
};
